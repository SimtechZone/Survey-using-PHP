<?php

session_start();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=devce-width, initial-scale=1.0">
    <title>KR| Admin | Create User</title>
    <!--    Font Awesome -->
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500&family=Raleway:wght@400;500;600&family=Roboto+Slab:wght@300;400&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../style.css">
    <style type="text/css">
        .sign .container .user .formBx form button {
            min-width: 100px;
            background: #677eff;
            color: #fff;
            cursor: pointer;
            font-size: 16px;
            padding: 10px 20px;
            margin-top: 10px;
            outline: none;
            border: none;
            font-weight: 700;
            letter-spacing: 1px;
            transition: 0.5s;
        }

        .sign .container .user .formBx form button:hover {
            background: #38ACEC;
        }

    </style>
</head>

<body>

    <?php

    include '../connection.php';

    if(isset($_POST['submit'])){
        
        $name = mysqli_real_escape_string($con, $_POST['name']);
        $email = mysqli_real_escape_string($con, $_POST['email']);
        $pass = mysqli_real_escape_string($con, $_POST['pass']);
        $cpass = $_POST['cpass'];

        $str_pass = password_hash($pass, PASSWORD_BCRYPT);

        $pass_check = password_verify($cpass, $str_pass);

        $emailquery = " SELECT * FROM feedback WHERE email='$email' ";
        $query = mysqli_query($con, $emailquery);

        $emailcount = mysqli_num_rows($query);

        if ($emailcount > 0) {
            ?>
    <script>
        alert("Email already exists. Try another one");

    </script>
    <?php
        }
        else{
            if ($pass_check) {
                $insertquery = " insert into feedback (Username, email, pass) values('$name', '$email', '$str_pass')";

                $res = mysqli_query($con, $insertquery);

                if($res){
                    ?>
    <script>
        alert("Sign-up Successful");

    </script>
    <?php
                }
                else{
                    ?>
    <script>
        alert("Error - Signup Failed");

    </script>
    <?php
                }
            }
            else{
                ?>
    <script>
        alert("Passwords do not match.")

    </script>
    <?php
            }
        }
    }
    ?>
    <section class="sign">
        <div class="container">

            <div class="user signupBx">
                <div class="formBx">
                    <form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="post">
                        <h2>Create New User </h2>
                        <input type="text" name="name" placeholder="Username" required>
                        <input type="email" name="email" placeholder="Email Adress" required>
                        <input type="password" name="pass" placeholder="Create Password" required>
                        <input type="password" name="cpass" placeholder="Confirm Password" required>
                        <button type="submit" name="submit">Create User</button>
                        <!--<p class="signup">Already have an account ?<a href="../login.php" onclick="toggleForm();"> Log In</a></p>-->
                    </form>
                </div>
                <div class="imgBx">
                    <img src="https://images.unsplash.com/photo-1556155092-8707de31f9c4?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=334&q=80">
                </div>
            </div>
        </div>
    </section>
</body>

</html>


<!-- 
<option <?php if($_GET[sel] == 'one') echo"selected"; ?> > one </option>
<option <?php if($_GET[sel] == 'two') echo"selected"; ?> > two </option>
<option <?php if($_GET[sel] == 'three') echo"selected"; ?> > three </option>
<option <?php if($_GET[sel] == 'four') echo"selected"; ?> > four </option> -->
