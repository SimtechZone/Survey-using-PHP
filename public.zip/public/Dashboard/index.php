<?php

session_start();

if (!isset($_SESSION['username'])) {
    ?>
<script>
    alert("You are logged out");

</script>
<?php
    header('location:../login.php');
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=devce-width, initial-scale=1.0">
    <title>KR | Dashboard</title>
    <!--    Font Awesome -->
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500&family=Raleway:wght@400;500;600&family=Roboto+Slab:wght@300;400&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="navigation">
        <ul>
            <li>
                <a href="#">
                    <span class="icon"><i class="fa fa-home" aria-hidden="true"></i></span>
                    <span class="title">Home</span>
                </a>
            </li>
            <li>
                <a href="#">
                    <span class="icon"><i class="fa fa-user" aria-hidden="true"></i></span>
                    <span class="title">About</span>
                </a>
            </li>
            <li>
                <a href="#">
                    <span class="icon"><i class="fa fa-comment" aria-hidden="true"></i></span>
                    <span class="title">Contact</span>
                </a>
            </li>
            <li>
                <a href="#">
                    <span class="icon"><i class="fa fa-cog" aria-hidden="true"></i></span>
                    <span class="title">Dashboard</span>
                </a>
            </li>

            <li>
                <a href="../logout.php">
                    <span class="icon"><i class="fa fa-sign-out" aria-hidden="true"></i></span>
                    <span class="title">Log Out</span>
                </a>
            </li>
        </ul>
    </div>
    <div class="toggle" onclick="toggleMenu()"></div>

    <section>

        <div class="dashboard">
            <form action="<?php echo $_SERVER["PHP_SELF"];?>" method="POST">
                <div class="filter">
                    <select name="Status" id="status">
                        <option value="">All</option>
                        <option value="1">Completed</option>
                        <option value="3">Quotafull</option>
                        <option value="2">Terminated</option>
                    </select>
                    <select name="ID" id="ids">
                        <option value="PID">PID</option>
                        <option value="UID">UID</option>
                    </select>
                    <div class="search__box">
                        <input type="text" placeholder="Search UID/PID" name="id" required>
                        <button type="submit" name="search" class="btn"><i class="fa fa-search"></i></button>
                    </div>
                </div>
            </form>
            <div class="table-box">
                <div class="table-row table-head">
                    <div class="table-cell">
                        <p>S No</p>
                    </div>
                    <div class="table-cell">
                        <p>UID</p>
                    </div>
                    <div class="table-cell">
                        <p>PID</p>
                    </div>
                    <div class="table-cell">
                        <p>D&amp;T</p>
                    </div>
                    <div class="table-cell">
                        <p>IP Address</p>
                    </div>
                    <div class="table-cell">
                        <p>Survey Status</p>
                    </div>
                </div>
                <?php

                include '..\connection.php';

                $selectquery = " SELECT * FROM test" ; //Page Starting

                function idtype($idType){               //To show ID type selected for search
                    if ($idType === "PID") {
                        // echo " PID";
                        return "PID";
                    }
                    elseif ($idType === "UID") {
                        // echo " UID";
                        return "UID";
                    }
                }

                if (isset($_POST['search'])) {      //In case of search
                    if(!empty($_POST['Status'])) {
                        $st = $_POST['Status'];
                        // echo 'You have chosen: ' . $st;
                        $idType = idtype($_POST['ID']);
                        $typed = $_POST['id'];
                        if ($idType === "PID") {
                            $selectquery = " SELECT * FROM test WHERE( StatusNum = '$st') AND (Pid LIKE '%$typed%') ";
                        }elseif ($idType === "UID") {
                            $selectquery = " SELECT * FROM test WHERE( StatusNum = '$st') AND (Uid LIKE '%$typed%') ";
                        }
                    }
                    else{
                        $idType = idtype($_POST['ID']);
                        $typed = $_POST['id'];
                        if ($idType === "PID") {
                            $selectquery = " SELECT * FROM test WHERE Pid LIKE '%$typed%' ";
                        }elseif ($idType === "UID") {
                            $selectquery = " SELECT * FROM test WHERE Uid LIKE '%$typed%' ";
                        }
                    }
                    // if (!empty($_POST['ID'])) {
                    //  $sort = $_POST['ID'];
                    //  echo 'You have chosen: ' . $sort;
                    // }

                }

                

                $query = mysqli_query($con, $selectquery);

                $nums = mysqli_num_rows($query);
                $count = 1;
                if ($nums === 0) {
                    ?>
                <h1 class="prompt">No Data Found</h1>
                <?php
                }
                while ($res = mysqli_fetch_array($query)) {

                    ?>

                <div class="table-row">
                    <div class="table-cell">
                        <p><?php echo $count; ?></p>
                    </div>
                    <div class="table-cell">
                        <p><?php echo $res['Uid']; ?></p>
                    </div>
                    <div class="table-cell">
                        <p><?php echo $res['Pid']; ?></p>
                    </div>
                    <div class="table-cell">
                        <p><?php echo $res['DNT']; ?></p>
                    </div>
                    <div class="table-cell">
                        <p><?php echo $res['IPAdress']; ?></p>
                    </div>
                    <div class="table-cell" <?php

                            $statusnum = $res['StatusNum'];
                            if ($statusnum == 1) {
                                ?> style="background-color: #00ffcc;" <?php
                            }
                            elseif ($statusnum == 2) {
                                ?> style="background-color: #ff6699;" <?php
                            }
                            elseif ($statusnum == 3) {
                                ?> style="background-color: #ffcc66;" <?php
                            }

                        ?>>
                        <p><?php echo $res['Status'];?></p>
                    </div>
                </div>

                <?php
                    $count++;
                }
            ?>

                <!-- <div class="table-row">
                <div class="table-cell">
                    <p>1</p>
                </div>
                <div class="table-cell">
                    <p>4646864</p>
                </div>
                <div class="table-cell">
                    <p>946599</p>
                </div>
                <div class="table-cell">
                    <p>12-45-4546 45:56</p>
                </div>
                <div class="table-cell">
                    <p>445.455.56.456</p>
                </div>
                <div class="table-cell">
                    <p>Quotafull</p>
                </div>                 
            </div> -->
            </div>
        </div>
    </section>


    <script type="text/javascript">
        function toggleMenu() {
            let navigation = document.querySelector('.navigation');
            let toggle = document.querySelector('.toggle');
            navigation.classList.toggle('active');
            toggle.classList.toggle('active');
        }

    </script>
</body>

</html>
