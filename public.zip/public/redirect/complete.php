<!DOCTYPE html>
<html lang="en">

<head>
    <title>KR | Survey Completed</title>
   <?php include 'nav.php';?>

    <section class="completed">
        <div class="overlay"></div>
        <div class="content">
            <h2>Thank You! You Survey has been Completed</h2>
        </div>
    </section>

    <div class="opdetail">
        <table>
            <tr>
                <th>UID</th>
                <th>PID</th>
                <th>Date & Time</th>
                <th>IP Address</th>
                <th>Status</th>
            </tr>
            <tr>
                <td><?php 
                    $uid = $_GET["uid"] ;
                echo $uid; ?></td>
                <td><?php
                $pid = $_GET["pid"];
                 echo $pid
                  ?></td>
                <td>
                    <?php

    date_default_timezone_set('Asia/Kolkata');
    $date = date('y-m-d  h:i:s');
    echo $date;

    ?></td>
                <td id="getip">
                    <?php
    //whether ip is from share internet
    if (!empty($_SERVER['HTTP_CLIENT_IP']))   
      {
        $ip_address = $_SERVER['HTTP_CLIENT_IP'];
      }
    //whether ip is from proxy
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))  
      {
        $ip_address = $_SERVER['HTTP_X_FORWARDED_FOR'];
      }
    //whether ip is from remote address
    else
      {
        $ip_address = $_SERVER['REMOTE_ADDR'];
      }
    echo $ip_address;
    ?>
                </td>
                <td>
                    <?php $Status = "COMPLETE" ;
                    echo $Status; ?>
                </td>
            </tr>
        </table>
    </div>



    <!--  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js">
    </script>

    <script>
		var getIP;
//		Get IP Adress using Js
        $.getJSON("https://api.ipify.org?format=json", 
            function(data) {
              getIP =  data.ip;
                $("#getip").html(getIP);
            });

    </script> -->

<?php include 'footer.php';?>

</body>

</html>


<?php

include '../connection.php';
    
// $name = $_POST['user'];
// $mobile = $_POST['number'];
// $email = $_POST['email'];

$UID = $uid;
$PID = $pid;
$DATE_TIME = $date;
$IP_ADRESS = $ip_address;
$STATUS = $Status;


$insertquery = " insert into test (Pid, Uid, DNT, IPAdress, Status, StatusNum) values('$PID', '$UID', '$DATE_TIME', '$IP_ADRESS', '$STATUS', 1)";

$res = mysqli_query($con, $insertquery);

if($res){
    ?>
<script>
    alert("Data inserted properly");

</script>
<?php

}
?>
