
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content=" Survey, Quotation, Review and Register form Wizard by Ankit.">
    <meta name="author" content="Ankit">
    <!-- GOOGLE WEB FONT -->
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500&family=Raleway:wght@400;500;600&family=Roboto+Slab:wght@300;400&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Work+Sans:400,500,600" rel="stylesheet">

    <!-- BASE CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/menu.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="css/nav.css">
    <link rel="stylesheet" href="css/footer.css">

    <style>
        .nav-logo {
            position: absolute;
        }
    </style>

</head>

<body>
    <section class="navs">
        <div class="nav-logo">
            <h2 class="py-3">Logo</h2>
        </div>
        <ul class="nav justify-content-end lighten-4 py-4 ">
            <li class="nav-item">
                <a class="nav-link active" href="">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="">About</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="">Contact</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="">Admin Login</a>
            </li>
        </ul>
    </section>

    <nav>
        <ul class="cd-primary-nav">
            <li><a href="index.html" class="animated_link">Home</a></li>
            <li><a href="about.html" class="animated_link">About Us</a></li>
            <li><a href="contacts.html" class="animated_link">Contact Us</a></li>
            <li><a href="login.html" class="animated_link">Admin Login</a></li>
        </ul>
    </nav>
    <!-- /menu -->
    <div class="cd-overlay-nav">
        <span></span>
    </div>
    <!-- /cd-overlay-nav -->

    <div class="cd-overlay-content">
        <span></span>
    </div>
    <!-- /cd-overlay-content -->

    <a href="#0" class="cd-nav-trigger"><span class="cd-icon"></span></a>
