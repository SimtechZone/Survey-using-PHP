 <?php

$username = "root";
$password = "";
$server  = "localhost";
$db = "testrun";

$con = mysqli_connect($server, $username, $password, $db);

if ($con) {
	// echo "Connection Successful";
	?>

 <script>
     alert('connection Successful');

 </script>

 <?php
}
else{
	echo "Connection failed";
}

 ?>
