<?php

session_start();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=devce-width, initial-scale=1.0">
    <title>KR | Admin LogIn</title>
    <!--    Font Awesome -->
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500&family=Raleway:wght@400;500;600&family=Roboto+Slab:wght@300;400&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style type="text/css">
        .sign .container .user .formBx form button {
            min-width: 100px;
            background: #677eff;
            color: #fff;
            cursor: pointer;
            font-size: 16px;
            padding: 10px 20px;
            margin-top: 10px;
            outline: none;
            border: none;
            font-weight: 700;
            letter-spacing: 1px;
            transition: 0.5s;
        }

        .sign .container .user .formBx form button:hover {
            background: #38ACEC;
        }

    </style>
</head>

<body>

    <?php

    include 'connection.php';

    if (isset($_POST['Login'])) {
        $user = $_POST['user'];
        $pass = $_POST['pass'];

        $user_search = " SELECT * FROM feedback WHERE email='$user' ";
        $query = mysqli_query($con, $user_search);

        $email_count = mysqli_num_rows($query);

        if ($email_count) {
            $email_pass = mysqli_fetch_assoc($query);
            $dbpass = $email_pass['pass'];
            $_SESSION['username'] = $email_pass['email'];
            $pass_decode = password_verify($pass, $dbpass);
            if ($pass_decode) {
                ?>
    <script>
        alert("Login Successful");
        location.replace("Dashboard/index.php");

    </script>
    <?php
            }
            else{
                ?>
    <script>
        alert("Password Incorrect");

    </script>
    <?php
            }
        }
        else{
            ?>
    <script>
        alert("Invalid Email");

    </script>
    <?php
        }
    }

    ?>

    <section class="sign">
        <div class="container">
            <div class="user signinBx">
                <div class="imgBx">
                    <img src="https://images.unsplash.com/photo-1559056961-1f4dbbf9d36a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=334&q=80">
                </div>
                <div class="formBx">
                    <form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="post">
                        <h2>Admin Log In</h2>
                        <input type="text" name="user" placeholder="Username">
                        <input type="password" name="pass" placeholder="Password">
                        <button type="submit" name="Login">LOG IN</button>
                    </form>
                </div>
            </div>
        </div>
    </section>
</body>

</html>
